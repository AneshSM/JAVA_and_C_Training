package spring_core_constructor_injection;

public class User {

	int id;
	String name;
	public User(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
}
